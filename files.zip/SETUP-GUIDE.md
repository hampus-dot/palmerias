# TeamSync Setup Guide

Complete step-by-step guide to get your football team dashboard up and running.

## Prerequisites

- Node.js 18 or higher
- npm or pnpm
- Git (optional)
- A code editor (VS Code recommended)

## Step 1: Create Accounts

### 1.1 Supabase (Database)

1. Go to https://supabase.com
2. Click "Start your project"
3. Create a new organization and project
4. Wait for project to initialize (~2 minutes)
5. Go to Settings → API
6. Copy:
   - `Project URL` → `PUBLIC_SUPABASE_URL`
   - `anon public` key → `PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` key → `SUPABASE_SERVICE_ROLE_KEY`

### 1.2 Clerk (Authentication)

1. Go to https://clerk.com
2. Sign up and create a new application
3. Choose "Email" and "Password" as authentication methods
4. Go to API Keys
5. Copy:
   - `Publishable key` → `PUBLIC_CLERK_PUBLISHABLE_KEY`
   - `Secret key` → `CLERK_SECRET_KEY`

### 1.3 Google Cloud Platform (Calendar API)

1. Go to https://console.cloud.google.com
2. Create a new project
3. Enable Google Calendar API:
   - Go to "APIs & Services" → "Library"
   - Search for "Google Calendar API"
   - Click "Enable"
4. Create OAuth credentials:
   - Go to "APIs & Services" → "Credentials"
   - Click "Create Credentials" → "OAuth client ID"
   - Choose "Web application"
   - Add authorized redirect URI: `http://localhost:5173/auth/google/callback`
   - Copy Client ID and Client Secret

## Step 2: Project Setup

### 2.1 Install Dependencies

```bash
npm install
```

### 2.2 Configure Environment Variables

1. Copy `.env.example` to `.env`
2. Fill in all the keys from Step 1

```bash
cp .env.example .env
```

Edit `.env` with your actual values.

## Step 3: Database Setup

### 3.1 Run SQL Migration

1. Open Supabase Dashboard
2. Go to SQL Editor
3. Click "New query"
4. Copy contents of `supabase-schema.sql`
5. Paste and click "Run"

This creates all tables, policies, and sample data.

### 3.2 Verify Database

Check that these tables exist:
- users
- matches
- match_availability
- training_sessions
- training_attendance
- league_table
- notifications

## Step 4: Clerk Configuration

### 4.1 Add Custom User Fields

In Clerk Dashboard:

1. Go to "User & Authentication" → "Email, Phone, Username"
2. Enable "Username" (optional)
3. Go to "Customization" → "Organization Settings"
4. Enable organizations if you want multi-team support

### 4.2 Set Webhook (Optional)

For automatic user sync:

1. In Clerk Dashboard, go to "Webhooks"
2. Add endpoint: `https://your-domain.com/api/webhooks/clerk`
3. Select events: `user.created`, `user.updated`
4. Copy signing secret to `.env` as `CLERK_WEBHOOK_SECRET`

## Step 5: Google Calendar Setup

### 5.1 OAuth Consent Screen

1. In Google Cloud Console, go to "OAuth consent screen"
2. Choose "External" user type
3. Fill in:
   - App name: "TeamSync"
   - User support email: your email
   - Developer contact: your email
4. Add scopes:
   - `https://www.googleapis.com/auth/calendar.events`
5. Add test users (your email and team manager emails)

### 5.2 First-time Authorization

When you first create a match:
1. System will redirect to Google OAuth
2. Sign in with Google
3. Approve access
4. You'll be redirected back with credentials saved

## Step 6: Run the Application

### 6.1 Development Mode

```bash
npm run dev
```

Visit `http://localhost:5173`

### 6.2 First Login

1. Click "Sign In"
2. Create an account (email + password)
3. Clerk will create your account
4. You'll be redirected to dashboard

### 6.3 Set Your Role

By default, new users are "players". To become admin:

1. Go to Supabase Dashboard → Table Editor
2. Open `users` table
3. Find your user by email
4. Change `role` to `admin` or `manager`
5. Refresh the app

## Step 7: Configure Features

### 7.1 Add Team Players

As admin/manager:
1. Go to "Players" section
2. Click "Add Player"
3. Fill in player details
4. Select role (player/manager/admin)
5. Player will receive Clerk invitation email

### 7.2 Create First Match

1. Go to "Schedule"
2. Click "Add Match"
3. Fill in match details
4. Select players to invite
5. Click "Create Match & Send Calendar Invites"
6. Players receive Google Calendar invites

### 7.3 Setup League Table

1. Go to "League Table"
2. Add teams in your league
3. Update standings after each match

### 7.4 Track Training

1. Go to "Training"
2. Click "Mark Attendance"
3. Select date
4. Check present players
5. Save attendance

## Step 8: Customization

### 8.1 Branding

Edit `tailwind.config.js`:

```javascript
colors: {
  pitch: {
    DEFAULT: '#00ff87', // Your team color
    dark: '#00cc6a'
  }
}
```

### 8.2 Team Name

Edit in header components and metadata.

### 8.3 Add Team Logo

1. Add logo to `static/logo.png`
2. Update references in components

## Step 9: Production Deployment

### 9.1 Build for Production

```bash
npm run build
```

### 9.2 Deploy to Vercel (Recommended)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

Or use Vercel GitHub integration:
1. Push code to GitHub
2. Import repository in Vercel
3. Add environment variables
4. Deploy

### 9.3 Update Environment Variables

In Vercel dashboard:
- Add all `.env` variables
- Update `GOOGLE_REDIRECT_URI` to your production domain
- Update Clerk allowed origins

### 9.4 Update Google Cloud

1. Add production URL to authorized redirect URIs
2. Remove localhost from production credentials

## Troubleshooting

### Database Connection Issues

**Error**: "Failed to connect to Supabase"

**Solution**:
- Verify `PUBLIC_SUPABASE_URL` and `PUBLIC_SUPABASE_ANON_KEY`
- Check Supabase project status
- Ensure RLS policies are correctly set

### Authentication Issues

**Error**: "Clerk authentication failed"

**Solution**:
- Verify Clerk API keys
- Check allowed origins in Clerk dashboard
- Clear browser cookies and try again

### Calendar Integration Issues

**Error**: "Failed to create calendar event"

**Solution**:
- Verify Google Calendar API is enabled
- Check OAuth credentials
- Ensure test users are added in OAuth consent screen
- Re-authorize application

### Role Permission Issues

**Error**: "You don't have permission"

**Solution**:
- Check user role in Supabase `users` table
- Verify RLS policies are correct
- Check Clerk user metadata

### Build Issues

**Error**: Module not found or TypeScript errors

**Solution**:
```bash
# Clear cache and reinstall
rm -rf node_modules
rm package-lock.json
npm install

# Clear build cache
rm -rf .svelte-kit
npm run build
```

## Common Tasks

### Reset Database

```bash
# In Supabase SQL Editor, run:
DROP SCHEMA public CASCADE;
CREATE SCHEMA public;
# Then re-run supabase-schema.sql
```

### Add New User Role

1. Update `user_role` enum in database
2. Update `types.ts`
3. Update RLS policies
4. Update UI role selectors

### Backup Database

In Supabase Dashboard:
1. Go to Database → Backups
2. Enable Point-in-Time Recovery
3. Download manual backups regularly

## Support

- SvelteKit Docs: https://kit.svelte.dev/docs
- Supabase Docs: https://supabase.com/docs
- Clerk Docs: https://clerk.com/docs
- shadcn-svelte: https://shadcn-svelte.com/docs

## Next Steps

- [ ] Add match statistics tracking
- [ ] Implement player performance metrics
- [ ] Add injury tracking
- [ ] Create mobile app version
- [ ] Add WhatsApp/SMS notifications
- [ ] Implement payment tracking for team fees
- [ ] Add equipment inventory management

---

Need help? Open an issue or contact your team admin!
