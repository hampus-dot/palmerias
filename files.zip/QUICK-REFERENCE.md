# TeamSync Quick Reference

## Common Operations

### Authentication

#### Check if user is logged in
```typescript
import { user } from '@clerk/sveltekit';

$: isLoggedIn = !!$user;
```

#### Get current user role
```typescript
const { data: currentUser } = await supabase
  .from('users')
  .select('role')
  .eq('clerk_user_id', $user.id)
  .single();

const isAdmin = currentUser?.role === 'admin';
const isManager = currentUser?.role === 'manager';
```

### Matches

#### Fetch upcoming matches
```typescript
const { data: matches } = await supabase
  .from('matches')
  .select('*')
  .gte('match_date', new Date().toISOString())
  .order('match_date', { ascending: true });
```

#### Create a match
```typescript
const { data: newMatch } = await supabase
  .from('matches')
  .insert({
    opponent: 'Thunder FC',
    match_date: '2025-12-15T18:00:00Z',
    location: 'Home Stadium',
    match_type: 'league',
    home_away: 'home'
  })
  .select()
  .single();
```

#### Set player availability
```typescript
await supabase
  .from('match_availability')
  .upsert({
    match_id: matchId,
    user_id: userId,
    status: 'available' // or 'unavailable'
  });
```

#### Get availability stats
```typescript
const { data: stats } = await supabase
  .rpc('get_match_availability_stats', { match_uuid: matchId });

// Returns: { total_players, available, unavailable, pending }
```

### Training

#### Create training session
```typescript
const { data: session } = await supabase
  .from('training_sessions')
  .insert({
    session_date: '2025-12-10T17:00:00Z',
    location: 'Training Ground',
    notes: 'Focus on tactics'
  })
  .select()
  .single();
```

#### Mark attendance
```typescript
const attendance = presentPlayerIds.map(id => ({
  training_id: sessionId,
  player_id: id,
  present: true
}));

await supabase
  .from('training_attendance')
  .insert(attendance);
```

#### Get player training rate
```typescript
const { data: rate } = await supabase
  .rpc('get_player_training_rate', { player_uuid: playerId });

// Returns: percentage (e.g., 85.50)
```

### Players

#### Fetch all players
```typescript
const { data: players } = await supabase
  .from('users')
  .select('*')
  .order('name', { ascending: true });
```

#### Add new player
```typescript
const { data: player } = await supabase
  .from('users')
  .insert({
    clerk_user_id: 'clerk_xxx',
    email: 'player@team.com',
    name: 'John Doe',
    role: 'player',
    position: 'Forward',
    jersey_number: 10
  })
  .select()
  .single();
```

#### Update player profile
```typescript
await supabase
  .from('users')
  .update({
    position: 'Midfielder',
    jersey_number: 8
  })
  .eq('id', playerId);
```

### League Table

#### Fetch standings
```typescript
const { data: standings } = await supabase
  .from('league_table')
  .select('*')
  .order('points', { ascending: false })
  .order('goal_difference', { ascending: false });
```

#### Update team stats
```typescript
await supabase
  .from('league_table')
  .update({
    played: 12,
    won: 7,
    drawn: 3,
    lost: 2,
    goals_for: 22,
    goals_against: 12
  })
  .eq('team_name', 'Your Team FC');

// Note: points and goal_difference are auto-calculated
```

### Notifications

#### Create notification
```typescript
await supabase
  .from('notifications')
  .insert({
    user_id: userId,
    title: 'Match Reminder',
    message: 'You have a match tomorrow at 18:00',
    type: 'match_reminder'
  });
```

#### Fetch unread notifications
```typescript
const { data: notifications } = await supabase
  .from('notifications')
  .select('*')
  .eq('user_id', userId)
  .eq('read', false)
  .order('created_at', { ascending: false });
```

#### Mark as read
```typescript
await supabase
  .from('notifications')
  .update({ read: true })
  .eq('id', notificationId);
```

### Google Calendar

#### Send calendar invite
```typescript
import { createMatchCalendarEvent } from '$lib/calendar';

const eventId = await createMatchCalendarEvent(
  match,
  ['player1@team.com', 'player2@team.com']
);
```

## Role-Based Access Control

### Check permissions in components
```typescript
<script lang="ts">
  import { user } from '@clerk/sveltekit';
  import { supabase } from '$lib/supabase';
  
  let userRole: string;
  
  onMount(async () => {
    const { data } = await supabase
      .from('users')
      .select('role')
      .eq('clerk_user_id', $user.id)
      .single();
    
    userRole = data?.role;
  });
  
  $: canManage = userRole === 'admin' || userRole === 'manager';
  $: isAdmin = userRole === 'admin';
</script>

{#if canManage}
  <button>Add Match</button>
{/if}

{#if isAdmin}
  <button>Manage Users</button>
{/if}
```

### Server-side permission check
```typescript
// In +server.ts
export const POST: RequestHandler = async ({ request, locals }) => {
  const session = await locals.auth.getSession();
  
  const { data: user } = await supabase
    .from('users')
    .select('role')
    .eq('clerk_user_id', session.userId)
    .single();
  
  if (!['admin', 'manager'].includes(user.role)) {
    return json({ error: 'Unauthorized' }, { status: 403 });
  }
  
  // Proceed with operation
};
```

## Real-time Updates

### Subscribe to match changes
```typescript
const channel = supabase
  .channel('matches')
  .on(
    'postgres_changes',
    {
      event: '*',
      schema: 'public',
      table: 'matches'
    },
    (payload) => {
      console.log('Match updated:', payload.new);
      // Refresh matches
    }
  )
  .subscribe();

// Cleanup on component destroy
onDestroy(() => {
  channel.unsubscribe();
});
```

### Subscribe to availability changes
```typescript
supabase
  .channel(`match:${matchId}`)
  .on(
    'postgres_changes',
    {
      event: 'INSERT',
      schema: 'public',
      table: 'match_availability',
      filter: `match_id=eq.${matchId}`
    },
    () => {
      // Reload availability
    }
  )
  .subscribe();
```

## Common Queries

### Get match with full details
```sql
SELECT 
  m.*,
  ma.status,
  ma.user_id,
  u.name as player_name,
  u.position
FROM matches m
LEFT JOIN match_availability ma ON m.id = ma.match_id
LEFT JOIN users u ON ma.user_id = u.id
WHERE m.id = 'match-uuid';
```

### Get player statistics
```sql
SELECT 
  u.name,
  COUNT(DISTINCT ta.training_id) as training_sessions_attended,
  COUNT(DISTINCT ma.match_id) as matches_confirmed,
  ROUND(
    COUNT(DISTINCT ta.training_id) * 100.0 / 
    NULLIF((SELECT COUNT(*) FROM training_sessions), 0),
    2
  ) as attendance_rate
FROM users u
LEFT JOIN training_attendance ta ON u.id = ta.player_id AND ta.present = true
LEFT JOIN match_availability ma ON u.id = ma.user_id AND ma.status = 'available'
WHERE u.role = 'player'
GROUP BY u.id, u.name;
```

### Get upcoming matches with availability
```sql
SELECT 
  m.*,
  COUNT(ma.user_id) FILTER (WHERE ma.status = 'available') as available_count,
  COUNT(ma.user_id) FILTER (WHERE ma.status = 'unavailable') as unavailable_count,
  COUNT(ma.user_id) as total_responses
FROM matches m
LEFT JOIN match_availability ma ON m.id = ma.match_id
WHERE m.match_date >= NOW()
GROUP BY m.id
ORDER BY m.match_date ASC;
```

## Useful Components

### Loading Spinner
```svelte
<script>
  export let loading = false;
</script>

{#if loading}
  <div class="flex justify-center items-center p-4">
    <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-pitch"></div>
  </div>
{/if}
```

### Error Display
```svelte
<script>
  export let error: string | null = null;
</script>

{#if error}
  <div class="bg-destructive/10 border border-destructive text-destructive px-4 py-3 rounded">
    {error}
  </div>
{/if}
```

### Success Toast
```svelte
<script>
  import { toast } from 'svelte-sonner';
  
  function showSuccess(message: string) {
    toast.success(message);
  }
</script>
```

## Environment Variables

### Development
```env
PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_...
CLERK_SECRET_KEY=sk_test_...
PUBLIC_SUPABASE_URL=https://xxx.supabase.co
PUBLIC_SUPABASE_ANON_KEY=eyJ...
```

### Production
```env
PUBLIC_CLERK_PUBLISHABLE_KEY=pk_live_...
CLERK_SECRET_KEY=sk_live_...
PUBLIC_SUPABASE_URL=https://xxx.supabase.co
PUBLIC_SUPABASE_ANON_KEY=eyJ...
```

## Debugging Tips

### Check Supabase connection
```typescript
const { data, error } = await supabase.from('users').select('count');
if (error) console.error('Database error:', error);
else console.log('Connected! Users:', data);
```

### Check Clerk session
```typescript
import { auth } from '@clerk/sveltekit/server';

export const load = async ({ locals }) => {
  const session = await locals.auth.getSession();
  console.log('Session:', session);
};
```

### Inspect RLS policies
```sql
-- In Supabase SQL Editor
SELECT * FROM pg_policies WHERE tablename = 'matches';
```

## Performance Tips

1. **Use select() sparingly** - Only fetch needed columns
2. **Add indexes** - For frequently queried columns
3. **Use pagination** - Limit results with `.limit()` and `.range()`
4. **Cache static data** - League table, team info
5. **Real-time subscriptions** - Only for critical updates
6. **Batch operations** - Use `.insert()` with arrays

## Security Best Practices

1. **Never expose service role key** - Only use in server-side code
2. **Validate user input** - Always sanitize form data
3. **Use RLS policies** - Don't rely on client-side checks
4. **Implement rate limiting** - For API endpoints
5. **Log sensitive operations** - Track admin actions
6. **Regular backups** - Enable Supabase point-in-time recovery

---

For more details, see:
- Full Setup Guide: SETUP-GUIDE.md
- API Documentation: api-endpoints-example.ts
- Database Schema: supabase-schema.sql
