# TeamSync Architecture

## System Architecture Diagram

```mermaid
graph TB
    subgraph "Client Layer"
        A[Web Browser]
        B[Mobile Browser]
    end
    
    subgraph "Authentication"
        C[Clerk Auth]
    end
    
    subgraph "Frontend - SvelteKit"
        D[Pages/Routes]
        E[Components]
        F[API Endpoints]
        G[Stores/State]
    end
    
    subgraph "Backend Services"
        H[Supabase PostgreSQL]
        I[Google Calendar API]
    end
    
    subgraph "Database Tables"
        J[users]
        K[matches]
        L[match_availability]
        M[training_sessions]
        N[training_attendance]
        O[league_table]
        P[notifications]
    end
    
    A --> C
    B --> C
    C --> D
    D --> E
    D --> F
    F --> G
    F --> H
    F --> I
    H --> J
    H --> K
    H --> L
    H --> M
    H --> N
    H --> O
    H --> P
    I --> K
```

## User Flow - Create Match

```mermaid
sequenceDiagram
    participant M as Manager
    participant UI as Frontend
    participant API as API Endpoint
    participant DB as Supabase
    participant GC as Google Calendar
    participant P as Players
    
    M->>UI: Click "Add Match"
    UI->>M: Show form
    M->>UI: Fill details + select players
    UI->>API: POST /api/matches
    API->>DB: Create match record
    DB-->>API: Return match data
    API->>DB: Create availability records
    API->>DB: Get player emails
    API->>GC: Create calendar event
    GC-->>API: Return event ID
    API->>DB: Update match with event ID
    GC->>P: Send email invites
    API-->>UI: Return success
    UI->>M: Show success message
```

## User Flow - Set Availability

```mermaid
sequenceDiagram
    participant P as Player
    participant UI as Frontend
    participant API as API Endpoint
    participant DB as Supabase
    participant M as Manager
    
    P->>UI: View upcoming matches
    UI->>DB: Fetch matches
    DB-->>UI: Return matches
    P->>UI: Click "Available"
    UI->>API: POST availability
    API->>DB: Update/insert availability
    API->>DB: Create notification for managers
    DB-->>API: Confirm update
    API-->>UI: Return success
    UI->>M: Show notification badge
```

## Data Flow

```mermaid
graph LR
    A[User Action] --> B[SvelteKit Page]
    B --> C{Client or Server?}
    C -->|Client| D[Direct Supabase Call]
    C -->|Server| E[API Endpoint]
    E --> F[Supabase Client]
    D --> G[Database]
    F --> G
    G --> H[RLS Check]
    H -->|Allowed| I[Return Data]
    H -->|Denied| J[Return Error]
    I --> K[Update UI]
    J --> K
```

## Authentication Flow

```mermaid
graph TB
    A[User] --> B{Logged In?}
    B -->|No| C[Clerk Login Page]
    C --> D[Enter Credentials]
    D --> E[Clerk Auth]
    E --> F[JWT Token]
    F --> G[SvelteKit Session]
    B -->|Yes| G
    G --> H[Check User in Supabase]
    H -->|Exists| I[Load User Data]
    H -->|New| J[Create User Record]
    J --> I
    I --> K[Check Role]
    K --> L[Load Dashboard]
```

## Role-Based Access Control

```mermaid
graph TB
    A[User Request] --> B{Check Role}
    B -->|Player| C[Player Access]
    B -->|Manager| D[Manager Access]
    B -->|Admin| E[Admin Access]
    
    C --> F[View Schedule]
    C --> G[Set Availability]
    C --> H[View Stats]
    
    D --> F
    D --> G
    D --> H
    D --> I[Create Matches]
    D --> J[Mark Attendance]
    D --> K[Send Invites]
    
    E --> F
    E --> G
    E --> H
    E --> I
    E --> J
    E --> K
    E --> L[Manage Users]
    E --> M[Edit League Table]
    E --> N[Full System Access]
```

## Database Relationships

```mermaid
erDiagram
    USERS ||--o{ MATCHES : creates
    USERS ||--o{ MATCH_AVAILABILITY : has
    USERS ||--o{ TRAINING_ATTENDANCE : has
    MATCHES ||--o{ MATCH_AVAILABILITY : tracks
    TRAINING_SESSIONS ||--o{ TRAINING_ATTENDANCE : has
    USERS ||--o{ NOTIFICATIONS : receives
    
    USERS {
        uuid id PK
        text clerk_user_id UK
        text email UK
        text name
        enum role
        text position
        int jersey_number
    }
    
    MATCHES {
        uuid id PK
        text opponent
        timestamp match_date
        text location
        enum match_type
        enum home_away
        text calendar_event_id
        uuid created_by FK
    }
    
    MATCH_AVAILABILITY {
        uuid id PK
        uuid match_id FK
        uuid user_id FK
        enum status
    }
    
    TRAINING_SESSIONS {
        uuid id PK
        timestamp session_date
        text location
        uuid created_by FK
    }
    
    TRAINING_ATTENDANCE {
        uuid id PK
        uuid training_id FK
        uuid player_id FK
        boolean present
    }
    
    LEAGUE_TABLE {
        uuid id PK
        text team_name
        int played
        int won
        int drawn
        int lost
        int points
    }
    
    NOTIFICATIONS {
        uuid id PK
        uuid user_id FK
        text title
        text message
        boolean read
    }
```

## Deployment Architecture

```mermaid
graph TB
    subgraph "Vercel Edge Network"
        A[Global CDN]
        B[Edge Functions]
    end
    
    subgraph "Application"
        C[SvelteKit App]
        D[Static Assets]
    end
    
    subgraph "External Services"
        E[Clerk Auth]
        F[Supabase DB]
        G[Google APIs]
    end
    
    A --> C
    A --> D
    C --> B
    B --> E
    B --> F
    B --> G
    
    subgraph "Database"
        H[PostgreSQL]
        I[Storage]
        J[Realtime]
    end
    
    F --> H
    F --> I
    F --> J
```

## Security Layers

```mermaid
graph TB
    A[Client Request] --> B[HTTPS/TLS]
    B --> C[Clerk JWT Verification]
    C --> D[SvelteKit Middleware]
    D --> E[API Route Handler]
    E --> F[Supabase Client]
    F --> G[Row Level Security]
    G --> H[Database]
    
    style B fill:#00ff87
    style C fill:#00ff87
    style G fill:#00ff87
```

## Feature Modules

```mermaid
graph LR
    A[TeamSync] --> B[Dashboard]
    A --> C[Schedule]
    A --> D[Players]
    A --> E[Training]
    A --> F[League]
    
    B --> B1[Quick Stats]
    B --> B2[Next Match]
    B --> B3[Recent Activity]
    
    C --> C1[Upcoming Matches]
    C --> C2[Match Creation]
    C --> C3[Availability Tracking]
    C --> C4[Calendar Integration]
    
    D --> D1[Player List]
    D --> D2[Add Players]
    D --> D3[Player Stats]
    D --> D4[Role Management]
    
    E --> E1[Session Calendar]
    E --> E2[Attendance Tracking]
    E --> E3[Attendance Stats]
    
    F --> F1[League Standings]
    F --> F2[Team Management]
    F --> F3[Match Results]
```

## Technology Stack

```mermaid
graph TB
    subgraph "Frontend"
        A[SvelteKit]
        B[TypeScript]
        C[Tailwind CSS]
        D[shadcn-svelte]
    end
    
    subgraph "Backend"
        E[Supabase]
        F[PostgreSQL]
        G[Row Level Security]
    end
    
    subgraph "Auth & APIs"
        H[Clerk]
        I[Google Calendar]
    end
    
    subgraph "Development"
        J[Vite]
        K[ESLint]
        L[TypeScript]
    end
    
    subgraph "Deployment"
        M[Vercel]
        N[GitHub]
    end
    
    A --> B
    A --> C
    A --> D
    E --> F
    E --> G
    A --> E
    A --> H
    A --> I
    J --> A
    M --> A
```

## Performance Optimization

```mermaid
graph LR
    A[Request] --> B{Cached?}
    B -->|Yes| C[Return from Cache]
    B -->|No| D[Fetch from Database]
    D --> E[Apply RLS]
    E --> F[Return Data]
    F --> G[Cache Result]
    G --> C
    C --> H[Send to Client]
```

---

These diagrams illustrate the complete architecture, data flow, and relationships in the TeamSync system. They can be viewed using any Mermaid-compatible viewer or in GitHub markdown files.
