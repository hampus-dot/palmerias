# TeamSync Troubleshooting Guide

## Common Issues & Solutions

### 🔴 Installation & Setup Issues

#### Issue: `npm install` fails
**Symptoms:**
- Error messages during package installation
- Missing dependencies

**Solutions:**
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules and lock file
rm -rf node_modules package-lock.json

# Try with legacy peer deps
npm install --legacy-peer-deps

# Or use pnpm instead
npm install -g pnpm
pnpm install
```

#### Issue: Environment variables not loading
**Symptoms:**
- `undefined` values for env variables
- "Missing environment variable" errors

**Solutions:**
1. Verify `.env` file exists in project root
2. Check variable names start with `PUBLIC_` for client-side access
3. Restart dev server after changing `.env`
4. In production, verify Vercel environment variables are set

```bash
# Check if .env exists
ls -la .env

# Verify environment variables are loaded
# Add to +page.server.ts
export const load = () => {
  console.log('PUBLIC_SUPABASE_URL:', import.meta.env.PUBLIC_SUPABASE_URL);
};
```

---

### 🔴 Database Issues

#### Issue: "Failed to connect to Supabase"
**Symptoms:**
- No data loading
- Connection timeout errors

**Solutions:**
1. Verify Supabase project is active (not paused)
2. Check API keys are correct
3. Verify network connectivity
4. Check Supabase status page

```typescript
// Test connection
const { data, error } = await supabase.from('users').select('count');
if (error) console.error('Connection error:', error);
else console.log('Connected successfully!');
```

#### Issue: "Permission denied" when querying
**Symptoms:**
- RLS policy errors
- "new row violates row-level security policy"

**Solutions:**
1. Check RLS policies are created correctly
2. Verify user authentication
3. Ensure user role is set correctly

```sql
-- Check RLS policies
SELECT * FROM pg_policies WHERE tablename = 'matches';

-- Temporarily disable RLS for testing (dev only!)
ALTER TABLE matches DISABLE ROW LEVEL SECURITY;
-- Remember to re-enable:
ALTER TABLE matches ENABLE ROW LEVEL SECURITY;
```

#### Issue: User not syncing between Clerk and Supabase
**Symptoms:**
- User exists in Clerk but not in Supabase
- `user not found` errors

**Solutions:**
```typescript
// Manually sync user
import { syncClerkUser } from '$lib/supabase';

export const load = async ({ locals }) => {
  const session = await locals.auth.getSession();
  if (session) {
    await syncClerkUser(session.user);
  }
};
```

---

### 🔴 Authentication Issues

#### Issue: "Unauthorized" errors
**Symptoms:**
- Can't access protected routes
- Session not persisting

**Solutions:**
1. Clear browser cookies
2. Check Clerk publishable key
3. Verify Clerk webhook is configured (if using)
4. Check browser console for auth errors

```typescript
// Debug auth state
import { user } from '@clerk/sveltekit';

$: console.log('User:', $user);
$: console.log('Authenticated:', !!$user);
```

#### Issue: User role not working
**Symptoms:**
- Always shows as 'player'
- Can't access manager/admin features

**Solutions:**
1. Check `users` table in Supabase
2. Manually update role in database
3. Clear session and log in again

```sql
-- Update user role
UPDATE users 
SET role = 'manager' 
WHERE email = 'your-email@team.com';
```

---

### 🔴 Calendar Integration Issues

#### Issue: Calendar events not creating
**Symptoms:**
- No error but no calendar invite
- "Failed to create calendar event"

**Solutions:**
1. Verify Google Calendar API is enabled
2. Check OAuth credentials
3. Ensure test users are added
4. Re-authorize application

```typescript
// Test calendar API
import { getAuthUrl } from '$lib/calendar';

// Visit this URL to authorize
console.log('Auth URL:', getAuthUrl());
```

#### Issue: Calendar invites not sending
**Symptoms:**
- Event created but no email sent
- Players not receiving invites

**Solutions:**
1. Check `sendUpdates` parameter is set to `'all'`
2. Verify player emails are correct
3. Check spam folders
4. Ensure Gmail API is enabled

```typescript
// Verify email list
const { data: players } = await supabase
  .from('users')
  .select('email')
  .in('id', playerIds);

console.log('Sending invites to:', players.map(p => p.email));
```

---

### 🔴 UI/Display Issues

#### Issue: Styles not loading
**Symptoms:**
- Unstyled or broken layout
- Tailwind classes not working

**Solutions:**
```bash
# Rebuild Tailwind
npm run build

# Check Tailwind config
npx tailwindcss -o test.css

# Clear SvelteKit cache
rm -rf .svelte-kit
npm run dev
```

#### Issue: Components not rendering
**Symptoms:**
- Blank page
- Component errors in console

**Solutions:**
1. Check browser console for errors
2. Verify imports are correct
3. Check component syntax

```svelte
<!-- Debug component -->
<script>
  console.log('Component mounted');
  
  // Check props
  export let data;
  console.log('Data:', data);
</script>

{#if data}
  <div>Data loaded</div>
{:else}
  <div>No data</div>
{/if}
```

---

### 🔴 Build & Deployment Issues

#### Issue: Build fails in production
**Symptoms:**
- Works locally but fails on Vercel
- TypeScript errors during build

**Solutions:**
```bash
# Check build locally
npm run build

# Check for type errors
npm run check

# Fix TypeScript errors
npm run check --watch
```

#### Issue: Environment variables not working in production
**Symptoms:**
- App works locally but not deployed
- API calls failing

**Solutions:**
1. Add ALL env variables to Vercel dashboard
2. Ensure `PUBLIC_` prefix for client-side vars
3. Redeploy after adding variables
4. Check Vercel function logs

#### Issue: 404 errors in production
**Symptoms:**
- Routes work locally but 404 in production
- Static files not found

**Solutions:**
```javascript
// Check svelte.config.js adapter
import adapter from '@sveltejs/adapter-vercel';

export default {
  kit: {
    adapter: adapter()
  }
};
```

---

### 🔴 Performance Issues

#### Issue: Slow page loads
**Symptoms:**
- Long loading times
- Timeouts

**Solutions:**
1. Add loading states
2. Implement pagination
3. Use selective queries
4. Add indexes to database

```typescript
// Optimize query
const { data } = await supabase
  .from('matches')
  .select('id, opponent, match_date') // Only needed fields
  .gte('match_date', new Date().toISOString())
  .order('match_date', { ascending: true })
  .limit(10); // Limit results
```

#### Issue: Real-time subscriptions causing issues
**Symptoms:**
- Multiple connections
- Memory leaks

**Solutions:**
```typescript
import { onDestroy } from 'svelte';

const channel = supabase.channel('matches').subscribe();

// Always clean up
onDestroy(() => {
  channel.unsubscribe();
});
```

---

### 🔴 Data Issues

#### Issue: Dates showing wrong timezone
**Symptoms:**
- Match times off by hours
- Training sessions at wrong time

**Solutions:**
```typescript
// Always use ISO format
const matchDate = new Date('2025-12-15T18:00:00Z'); // Z = UTC

// Display in user timezone
const displayDate = new Date(match.match_date).toLocaleString();
```

#### Issue: Availability counts wrong
**Symptoms:**
- Shows wrong number of available players
- Stats don't match

**Solutions:**
```typescript
// Use the database function
const { data: stats } = await supabase
  .rpc('get_match_availability_stats', { match_uuid: matchId });

console.log('Stats:', stats);
```

---

### 🔴 Mobile Issues

#### Issue: Layout broken on mobile
**Symptoms:**
- Overlapping elements
- Horizontal scroll

**Solutions:**
1. Check responsive breakpoints
2. Test with mobile viewport
3. Use mobile-first approach

```css
/* Mobile first */
.container {
  padding: 1rem;
}

/* Desktop */
@media (min-width: 768px) {
  .container {
    padding: 2rem;
  }
}
```

#### Issue: Touch targets too small
**Symptoms:**
- Hard to click buttons on mobile
- Accidental clicks

**Solutions:**
```css
/* Minimum touch target: 44x44px */
.btn {
  min-height: 44px;
  min-width: 44px;
  padding: 0.75rem 1.5rem;
}
```

---

### 🔴 Google Cloud Issues

#### Issue: "Access blocked" when authorizing
**Symptoms:**
- Can't authorize Google Calendar
- "This app hasn't been verified" error

**Solutions:**
1. Add yourself as test user in OAuth consent screen
2. Click "Advanced" → "Go to [App Name] (unsafe)" during dev
3. Verify app for production use

#### Issue: API quota exceeded
**Symptoms:**
- Calendar events stop creating
- 429 error codes

**Solutions:**
1. Check quota in Google Cloud Console
2. Request quota increase
3. Implement rate limiting
4. Cache calendar event IDs

---

## Debugging Tools

### Check Database Connection
```typescript
// Add to +page.server.ts
export const load = async () => {
  const { data, error } = await supabase
    .from('users')
    .select('count');
  
  return {
    dbConnected: !error,
    error: error?.message
  };
};
```

### Check Authentication
```typescript
// Add to +layout.server.ts
export const load = async ({ locals }) => {
  const session = await locals.auth.getSession();
  
  return {
    authenticated: !!session,
    userId: session?.userId
  };
};
```

### Check API Endpoints
```bash
# Test with curl
curl -X GET http://localhost:5173/api/matches

# Test with authentication
curl -X GET http://localhost:5173/api/matches \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Browser DevTools Checklist
1. Console - Check for JavaScript errors
2. Network - Check API calls and responses
3. Application - Check localStorage and cookies
4. Sources - Set breakpoints in code

### Supabase Dashboard Tools
1. **Table Editor** - View/edit data directly
2. **SQL Editor** - Run custom queries
3. **Database > Functions** - Check RLS policies
4. **Logs** - View database logs
5. **API Docs** - Auto-generated API documentation

---

## Prevention Tips

### 1. Use Type Safety
```typescript
// Define types
import type { Match, User } from '$lib/types';

// Use them
const match: Match = await fetchMatch();
```

### 2. Error Handling
```typescript
try {
  const { data, error } = await supabase.from('matches').select();
  if (error) throw error;
  return data;
} catch (err) {
  console.error('Error:', err);
  return [];
}
```

### 3. Validation
```typescript
// Validate before saving
function validateMatch(match: any) {
  if (!match.opponent) throw new Error('Opponent required');
  if (!match.match_date) throw new Error('Date required');
  // ... more validation
}
```

### 4. Logging
```typescript
// Log important operations
console.log('[Match Created]', {
  id: match.id,
  opponent: match.opponent,
  timestamp: new Date()
});
```

### 5. Testing
```typescript
// Test critical functions
export function calculatePoints(won: number, drawn: number) {
  return won * 3 + drawn;
}

// In test file
import { test, expect } from 'vitest';

test('calculates points correctly', () => {
  expect(calculatePoints(5, 2)).toBe(17);
});
```

---

## Getting Help

### Before Asking for Help
1. Check browser console for errors
2. Check network tab for failed requests
3. Review relevant documentation
4. Try the solutions in this guide
5. Search GitHub issues

### When Asking for Help
Include:
- Error message (full stack trace)
- What you tried
- Browser/OS version
- Relevant code snippet
- Steps to reproduce

### Resources
- **SvelteKit Discord**: https://discord.gg/svelte
- **Supabase Discord**: https://discord.gg/supabase
- **Clerk Discord**: https://discord.gg/clerk
- **Stack Overflow**: Tag with `sveltekit`, `supabase`

---

## Emergency Fixes

### Reset Database
```sql
-- Backup first!
-- Then in Supabase SQL Editor:
DROP SCHEMA public CASCADE;
CREATE SCHEMA public;
-- Re-run supabase-schema.sql
```

### Clear All Data
```sql
-- Keep tables, delete data
TRUNCATE users, matches, match_availability, 
         training_sessions, training_attendance, 
         league_table, notifications CASCADE;
```

### Reset User Session
```typescript
// Client-side
import { invalidateAll } from '$app/navigation';
await invalidateAll();

// Or full page refresh
window.location.reload();
```

### Force Rebuild
```bash
rm -rf node_modules .svelte-kit
npm install
npm run dev
```

---

Remember: Most issues are configuration problems. Double-check your environment variables, API keys, and database setup first!
